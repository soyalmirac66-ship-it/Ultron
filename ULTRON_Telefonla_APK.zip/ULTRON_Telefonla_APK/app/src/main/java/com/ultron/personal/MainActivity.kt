package com.ultron.personal

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var webView: WebView
    private val prefs by lazy { getSharedPreferences("ultron_settings", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(25, 7, 13)
        window.navigationBarColor = Color.rgb(9, 11, 16)
        showServerSetup()
    }

    private fun showServerSetup() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
            setBackgroundColor(Color.rgb(9, 11, 16))
        }
        val title = TextView(this).apply {
            text = "ULTRON"
            textSize = 30f
            setTextColor(Color.rgb(255, 57, 77))
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "Kişisel yapay zekânı bağla\\n\\nÖnce ULTRON Python sunucunu HTTPS üzerinden yayınla. Bu uygulama sunucunun arayüzünü açar. API anahtarını APK içine koyma."
            textSize = 16f
            setTextColor(Color.LTGRAY)
            setPadding(0, 28, 0, 20)
        }
        val urlInput = EditText(this).apply {
            hint = "https://senin-guvenli-sunucun.example"
            setText(prefs.getString("server_url", "") ?: "")
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setSingleLine(true)
        }
        val connect = Button(this).apply {
            text = "ULTRON'a bağlan"
            setOnClickListener {
                var url = urlInput.text.toString().trim()
                if (url.isBlank()) {
                    Toast.makeText(this@MainActivity, "Önce sunucu adresini gir.", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                if (!url.startsWith("https://")) {
                    Toast.makeText(this@MainActivity, "Güvenlik için HTTPS adresi kullan.", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                prefs.edit().putString("server_url", url).apply()
                openWebApp(url)
            }
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(info, LinearLayout.LayoutParams(-1, -2))
        root.addView(urlInput, LinearLayout.LayoutParams(-1, -2))
        root.addView(connect, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    private fun openWebApp(url: String) {
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = false
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                if (url == null) return true
                return !url.startsWith("https://")
            }
        }
        webView.webChromeClient = WebChromeClient()
        setContentView(webView)
        webView.loadUrl(url)
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }
}
