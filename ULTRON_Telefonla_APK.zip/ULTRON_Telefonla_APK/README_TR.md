# ULTRON Android APK projesi

Bu klasör Android Studio ile APK üretmek için hazırlanmış bir Android uygulama projesidir. Android uygulaması, mevcut ULTRON Python web sunucusuna güvenli HTTPS üzerinden bağlanır.

## Önemli sınır
Bu, sunucu olmadan tek başına çalışan bir yapay zekâ APK'sı değildir. Model API anahtarı APK içine konulmamalıdır. Önce önceki `ULTRON_Android_Proje.zip` içindeki Python uygulamasını güvenli bir sunucuya kurup HTTPS adresi elde etmelisin. Ardından uygulamayı açıp bu adresi girebilirsin.

## APK nasıl üretilir?
1. Bilgisayarına Android Studio kur: https://developer.android.com/studio
2. Android Studio'da bu klasörü `Open` ile aç.
3. Gradle senkronizasyonunun bitmesini bekle. Android SDK Platform 35 ve JDK 17 gerekebilir.
4. `Build > Build Bundle(s) / APK(s) > Build APK(s)` seç.
5. APK genellikle `app/build/outputs/apk/debug/app-debug.apk` altında oluşur.
6. APK'yı Android telefonuna aktar ve kur. Android, bilinmeyen uygulama yükleme izni isteyebilir.

## Güvenlik
- Sunucunu HTTPS ile koru ve kimlik doğrulama eklemeden internete açma.
- API anahtarını Android uygulamasına veya kaynak koda ekleme.
- Bu örnek başlangıç kabuğudur; oturum açma/çok kullanıcılı erişim denetimi içermez.
