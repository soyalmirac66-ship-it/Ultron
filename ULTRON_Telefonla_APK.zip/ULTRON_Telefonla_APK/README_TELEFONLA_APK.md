# ULTRON — telefondan APK oluşturma

Bu proje, GitHub Actions kullanarak APK'yı bulutta oluşturabilmen için bir Android Studio projesi ve iş akışı içerir. Android uygulaması mevcut ULTRON Python sunucusuna HTTPS ile bağlanır; sunucunun kendisi bu APK'nın içinde değildir.

## Yalnızca telefonla APK oluşturma
1. ZIP'i telefona indir ve Dosyalar uygulamasında çıkar.
2. GitHub hesabın yoksa github.com üzerinden hesap aç veya giriş yap.
3. GitHub'da yeni, **Private** bir repository oluştur (ör. `ultron-android`).
4. Repo sayfasında `Add file` > `Upload files` ile bu klasördeki proje dosyalarını yükle. `.github/workflows/android-apk.yml` dosyasının da yüklendiğinden emin ol. ZIP dosyasının kendisini yüklemek yeterli değildir; içindeki dosyaları yüklemelisin. Android'de gizli `.github` klasörü görünmüyorsa, bu adım için GitHub Codespaces veya bir Android kod editörü gerekebilir.
5. Dosyalar `main` dalına commit edilince Actions sekmesindeki `ULTRON Android APK` işi başlar. İstersen Actions > ULTRON Android APK > Run workflow ile elle başlat.
6. İş tamamlanınca ilgili çalıştırmayı aç, `Artifacts` bölümündeki `ULTRON-debug-APK` dosyasını indir ve ZIP içinden `app-debug.apk` dosyasını çıkar.
7. APK'ya dokunarak kur. Android, tarayıcıya veya dosya yöneticisine “bilinmeyen uygulama yükleme” izni vermeni isteyebilir.

## Önemli
- Bu süreç için GitHub hesabı ve internet gerekir. GitHub Actions build süresi ve kullanım limitleri hesaba göre değişebilir.
- APK henüz kendi başına sohbet üretmez. Kurulum ekranına, ULTRON Python sunucunun güvenli HTTPS adresini girmen gerekir.
- API anahtarını GitHub'a veya APK'ya koyma.
- İlk kez uygulama geliştiriyorsan, GitHub web arayüzünde `.github` gibi gizli klasörleri telefondan yüklemek zor olabilir. Takılırsan hangi ekranda kaldığını yaz; adım adım ilerleyelim.
